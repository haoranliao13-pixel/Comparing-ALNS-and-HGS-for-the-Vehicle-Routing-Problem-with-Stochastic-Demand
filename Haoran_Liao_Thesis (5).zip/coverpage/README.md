﻿**TUM-template coverpage for scientific writings in LaTeX**

This template is direclty from the TUM Corporate Design webpage located here: http://portal.mytum.de/corporatedesign

Additional information and attributions can be found in the ```_Liesmich.txt```

